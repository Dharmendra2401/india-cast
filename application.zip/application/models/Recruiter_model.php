<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Recruiter_model extends CI_Model {

    public function authfalse(){
   
        $getrecruiter=$this->session->userdata('recruiter');
        if(!empty($getrecruiter)){
            redirect(base_url().'recruiter/index');
            return false;
        }
        }

        public function authtrue(){
            $getrecruiter=$this->session->userdata('recruiter');
            if(empty($getrecruiter)){
                redirect(base_url().'recruiter/login');
                return true;
            }
        }


        public function checkcrediential($email,$password){
            //$passwordss=$this->encrypt->decode($password);
            $querry=$this->db->query('SELECT id,email,password from recruiter where email="'.$email.'" and password="'.$password.'" ');
            $querrry=$querry->row_array();
            return  $querrry;

        }
    
        public function profile(){
            $query=$this->db->query('SELECT * from profiles where delete_flag="N"');
            $resultt=$query->result_array();
            return $resultt;
        }

        public function jobcount(){
            $query=$this->db->query('SELECT profile_ids from jobs');
            $resultjob=$query->result_array();
            return $resultjob;
           
        }

        public function getrecruiterprofile(){
            $getrecruiter=$this->session->userdata('recruiter');
            $query=$this->db->query('SELECT * from recruiter where id="'.$getrecruiter['recid'].'"');
            $recruiter=$query->row_array();
            return $recruiter;
           
        }

        public function jobs_list(){
            $getrecruiter=$this->session->userdata('recruiter');
            $query=$this->db->query('SELECT profile_ids from jobs where recruiter_id="'.$getrecruiter['recid'].'"');
            $resultjob=$query->result_array();
            return $resultjob;

        }

        public function city(){
            $query=$this->db->query('SELECT * from states_city_country where city!="" GROUP BY city ');
            $city=$query->result_array();
            return $city;

        }

       


}