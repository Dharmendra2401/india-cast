<?php $this->load->view('/common/header'); ?>
<!--script src="https://unpkg.com/masonry-layout@4/dist/masonry.pkgd.min.js"></script-->
<link href="https://fonts.googleapis.com/css?family=Limelight" rel="stylesheet">
<style>
    .img_overflow{    
        position: relative;
        min-height: 200px;
        max-height: 200px;
        overflow: hidden;
    }
    .text_heading11{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        padding: 15px;
        color: #fff;        
    }
    .nounderline{text-decoration: none !important}
    
    .class-margin-gallary{margin: 0 0px 30px 0px;}
    
    .item-grid{    
        background-color: #ececec;
        padding: 15px;
    }
</style>
<div class="col-md-12 somi">
	<img src="<?php echo base_url(); ?>/images/blog/blog-banner.jpg" class="img_res"/> 
</div>
<div class="clearfix"></div>
<div class="container">
	<div class="row">
		<div class="col-sm-9" style="margin-top: 2em;">
			<div class="grid">
			<div class="col-sm-6 grid-item class-margin-gallary">
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">27<br>Nov<br>2017</div>
				</div>
				<div class="col-sm-12 somi item-grid">
                                    <div class="img_overflow">
                                        <img src="http://www.castindia.in/images/blog/5a1bd344dca7c401.jpeg" class="img_res">
                                        <div class="text_heading11"></div>
                                    </div>
                                    <div style="margin-top:1em;color: #fe980f;"><i><strong>Author</strong> : Castindia Castindia</i></div>
                                    <div style="margin-top:0.3em;color: #fe980f;"><i><strong>Category</strong> : Art</i></div>
					<h2 style="font-size: 19px;">An exquisite abode for all...</h2>
					<!--p>So, you've decided that you want to be a model? That's great news! A modeling career is a world of excitement, but don't be fooled into thinking its an easy job. No way, think long hours, the potential for lots of travel meaning you'll be away from family and friends and irregular income... </p-->
					<p style="color:#146992;cursor:pointer;font-size: 18px;"><a class="nounderline" href="http://www.castindia.in/blogs/details?code=MzY=">Continue Reading..</a></p>
					<div class="clearfix"></div> 
				</div>
				<div class="clearfix"></div>
			</div>

            <div class="col-sm-6 grid-item class-margin-gallary">
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">27<br>Nov<br>2017</div>
				</div>
				<div class="col-sm-12 somi item-grid">
                                    <div class="img_overflow">
                                        <img src="http://www.castindia.in/images/blog/5a1bd344dca7c401.jpeg" class="img_res">
                                        <div class="text_heading11"></div>
                                    </div>
                                    <div style="margin-top:1em;color: #fe980f;"><i><strong>Author</strong> : Castindia Castindia</i></div>
                                    <div style="margin-top:0.3em;color: #fe980f;"><i><strong>Category</strong> : Art</i></div>
					<h2 style="font-size: 19px;">An exquisite abode for all...</h2>
					<!--p>So, you've decided that you want to be a model? That's great news! A modeling career is a world of excitement, but don't be fooled into thinking its an easy job. No way, think long hours, the potential for lots of travel meaning you'll be away from family and friends and irregular income... </p-->
					<p style="color:#146992;cursor:pointer;font-size: 18px;"><a class="nounderline" href="http://www.castindia.in/blogs/details?code=MzY=">Continue Reading..</a></p>
					<div class="clearfix"></div> 
				</div>
				<div class="clearfix"></div>
			</div>



            <div class="col-sm-6 grid-item class-margin-gallary">
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">27<br>Nov<br>2017</div>
				</div>
				<div class="col-sm-12 somi item-grid">
                                    <div class="img_overflow">
                                        <img src="http://www.castindia.in/images/blog/5a1bd344dca7c401.jpeg" class="img_res">
                                        <div class="text_heading11"></div>
                                    </div>
                                    <div style="margin-top:1em;color: #fe980f;"><i><strong>Author</strong> : Castindia Castindia</i></div>
                                    <div style="margin-top:0.3em;color: #fe980f;"><i><strong>Category</strong> : Art</i></div>
					<h2 style="font-size: 19px;">An exquisite abode for all...</h2>
					<!--p>So, you've decided that you want to be a model? That's great news! A modeling career is a world of excitement, but don't be fooled into thinking its an easy job. No way, think long hours, the potential for lots of travel meaning you'll be away from family and friends and irregular income... </p-->
					<p style="color:#146992;cursor:pointer;font-size: 18px;"><a class="nounderline" href="http://www.castindia.in/blogs/details?code=MzY=">Continue Reading..</a></p>
					<div class="clearfix"></div> 
				</div>
				<div class="clearfix"></div>
			</div>



            <div class="col-sm-6 grid-item class-margin-gallary">
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">27<br>Nov<br>2017</div>
				</div>
				<div class="col-sm-12 somi item-grid">
                                    <div class="img_overflow">
                                        <img src="http://www.castindia.in/images/blog/5a1bd344dca7c401.jpeg" class="img_res">
                                        <div class="text_heading11"></div>
                                    </div>
                                    <div style="margin-top:1em;color: #fe980f;"><i><strong>Author</strong> : Castindia Castindia</i></div>
                                    <div style="margin-top:0.3em;color: #fe980f;"><i><strong>Category</strong> : Art</i></div>
					<h2 style="font-size: 19px;">An exquisite abode for all...</h2>
					<!--p>So, you've decided that you want to be a model? That's great news! A modeling career is a world of excitement, but don't be fooled into thinking its an easy job. No way, think long hours, the potential for lots of travel meaning you'll be away from family and friends and irregular income... </p-->
					<p style="color:#146992;cursor:pointer;font-size: 18px;"><a class="nounderline" href="http://www.castindia.in/blogs/details?code=MzY=">Continue Reading..</a></p>
					<div class="clearfix"></div> 
				</div>
				<div class="clearfix"></div>
			</div>



            <div class="col-sm-6 grid-item class-margin-gallary">
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">27<br>Nov<br>2017</div>
				</div>
				<div class="col-sm-12 somi item-grid">
                                    <div class="img_overflow">
                                        <img src="http://www.castindia.in/images/blog/5a1bd344dca7c401.jpeg" class="img_res">
                                        <div class="text_heading11"></div>
                                    </div>
                                    <div style="margin-top:1em;color: #fe980f;"><i><strong>Author</strong> : Castindia Castindia</i></div>
                                    <div style="margin-top:0.3em;color: #fe980f;"><i><strong>Category</strong> : Art</i></div>
					<h2 style="font-size: 19px;">An exquisite abode for all...</h2>
					<!--p>So, you've decided that you want to be a model? That's great news! A modeling career is a world of excitement, but don't be fooled into thinking its an easy job. No way, think long hours, the potential for lots of travel meaning you'll be away from family and friends and irregular income... </p-->
					<p style="color:#146992;cursor:pointer;font-size: 18px;"><a class="nounderline" href="http://www.castindia.in/blogs/details?code=MzY=">Continue Reading..</a></p>
					<div class="clearfix"></div> 
				</div>
				<div class="clearfix"></div>
			</div>

			<!--<div class="col-sm-6 grid-item">
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">12<br/>June<br/>2017</div>
				</div>
				<div class="col-sm-12 somi">
					<img src="<?php echo base_url();; ?>/images/blog/blog-2.jpg" class="img_res"/>
					<p style="margin-top:1em;color: #fe980f;"><i>Author : Renu Navhekar</i></p>
					<h2 style="font-size: 19px;">Prepare for your first ever runway!</h2>
					<!--p>One of the many highlights of a modeling career is the chance to showcase a designer's new collection on the runway. If you've never stepped foot on the 'catwalk', it can be a daunting thing... taking to a long stage, in front of hundreds of people and flashing cameras all focused on you...</p-->
					<!--<p style="color:#146992;cursor:pointer;font-size: 18px;">Continue Reading..</p>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="col-sm-6 grid-item"> 
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">23<br/>July<br/>2017</div>
				</div>
				<div class="col-sm-12 somi">
					<img src="<?php echo base_url();; ?>/images/blog/blog-3.jpg" class="img_res"/>
					<p style="margin-top:1em;color: #fe980f;"><i>Author : Renu Navhekar</i></p>
					<h2 style="font-size: 19px;">Helping New York fashion photographer Bryan M. Sargent to find the perfect model</h2>
					<!--p>One of the many highlights of a modeling career is the chance to showcase a designer's new collection on the runway. If you've never stepped foot on the 'catwalk', it can be a daunting thing... taking to a long stage, in front of hundreds of people and flashing cameras all focused on you... </p-->
					<!--<p style="color:#146992;cursor:pointer;font-size: 18px;">Continue Reading..</p>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="col-sm-6 grid-item"> 
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">23<br/>July<br/>2017</div>
				</div>
				<div class="col-sm-12 somi">
					<img src="<?php echo base_url();; ?>/images/blog/blog-3.jpg" class="img_res"/>
					<p style="margin-top:1em;color: #fe980f;"><i>Author : Renu Navhekar</i></p>
					<h2 style="font-size: 19px;">Helping New York fashion photographer Bryan M. Sargent to find the perfect model</h2>
					<!--p>One of the many highlights of a modeling career is the chance to showcase a designer's new collection on the runway. If you've never stepped foot on the 'catwalk', it can be a daunting thing... taking to a long stage, in front of hundreds of people and flashing cameras all focused on you... </p-->
					<!--<p style="color:#146992;cursor:pointer;font-size: 18px;">Continue Reading..</p>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="col-sm-6 grid-item"> 
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">23<br/>July<br/>2017</div>
				</div>
				<div class="col-sm-12 somi">
					<img src="<?php echo base_url();; ?>/images/blog/blog-3.jpg" class="img_res"/>
					<p style="margin-top:1em;color: #fe980f;"><i>Author : Renu Navhekar</i></p>
					<h2 style="font-size: 19px;">Helping New York fashion photographer Bryan M. Sargent to find the perfect model</h2>
					<!--p>One of the many highlights of a modeling career is the chance to showcase a designer's new collection on the runway. If you've never stepped foot on the 'catwalk', it can be a daunting thing... taking to a long stage, in front of hundreds of people and flashing cameras all focused on you... </p-->
					<!--<p style="color:#146992;cursor:pointer;font-size: 18px;">Continue Reading..</p>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="col-sm-6 grid-item">
				<div class="col-xs-2 somi date_color">
					<div style="font-family: 'Limelight', cursive;">12<br/>June<br/>2017</div>
				</div>
				<div class="col-sm-12 somi">
					<img src="<?php echo base_url();; ?>/images/blog/blog-2.jpg" class="img_res"/>
					<p style="margin-top:1em;color: #fe980f;"><i>Author : Renu Navhekar</i></p>
					<h2 style="font-size: 19px;">Prepare for your first ever runway!</h2>
					<!--p>One of the many highlights of a modeling career is the chance to showcase a designer's new collection on the runway. If you've never stepped foot on the 'catwalk', it can be a daunting thing... taking to a long stage, in front of hundreds of people and flashing cameras all focused on you... </p-->
					<!--<p style="color:#146992;cursor:pointer;font-size: 18px;">Continue Reading..</p>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>-->
			</div>
			<!--script>
			$(document).ready(function(){		
				var elem = document.querySelector('.grid');
				var msnry = new Masonry( elem, {
				  // options
				  itemSelector: '.grid-item',
				  columnWidth: 200
				});

				// element argument can be a selector string
				//   for an individual element
				var msnry = new Masonry( '.grid', {
				  // options
				});
				})
			</script-->
		</div>
		
		
		<div class="col-sm-3" style="margin-top: 2em;background: #ececec;">
			<h4 class="list_heading1">Facebook Feeds</h4>
			<div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div></div></div></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.9&appId=520172514821695";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-page fb_iframe_widget" data-href="https://www.facebook.com/castindia/" data-tabs="timeline" data-height="300" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" fb-xfbml-state="rendered" fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=520172514821695&amp;container_width=263&amp;height=300&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2Fcastindia%2F&amp;locale=en_GB&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;tabs=timeline"><span style="vertical-align: bottom; width: 263px; height: 300px;"><iframe name="f119fbdccb09fe8" width="1000px" height="300px" data-testid="fb:page Facebook Social Plugin" title="fb:page Facebook Social Plugin" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="https://www.facebook.com/v2.9/plugins/page.php?adapt_container_width=true&amp;app_id=520172514821695&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fx%2Fconnect%2Fxd_arbiter%2F%3Fversion%3D46%23cb%3Df3e5fff0c2bf32%26domain%3Dwww.castindia.in%26origin%3Dhttp%253A%252F%252Fwww.castindia.in%252Ff99816d8ef6f5c%26relation%3Dparent.parent&amp;container_width=263&amp;height=300&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2Fcastindia%2F&amp;locale=en_GB&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;tabs=timeline" style="border: none; visibility: visible; width: 263px; height: 300px;" class=""></iframe></span></div>
									<h4 class="list_heading1" style="margin-top:1.5em;">Category</h4>
			<ul class="category_list category_list11">
									<li>Art<span class="badge_custom">8</span></li>
										<li>Youth<span class="badge_custom">2</span></li>
										<li>Trends<span class="badge_custom">6</span></li>
										<li>Life styles<span class="badge_custom">1</span></li>
										<li>New age Ideas<span class="badge_custom">2</span></li>
									<!--<li>Modeling World <span class="badge_custom">02</span></li>
				<li>Photography <span class="badge_custom">05</span></li>
				<li>Acting <span class="badge_custom">01</span></li>-->
			</ul>
						<h4 class="list_heading1" style="margin-top:1.5em;">Recent Blogs</h4> 
			<ul class="category_list">
									<li>An exquisite abode for all art forms						<p style="color:#146992;cursor:pointer;font-size: 15px;"><a href="http://www.castindia.in/blogs/details?code=MzY=">Continue Reading..</a></p>
					</li>
										<li>The Beginning of the Happy Ending						<p style="color:#146992;cursor:pointer;font-size: 15px;"><a href="http://www.castindia.in/blogs/details?code=MzU=">Continue Reading..</a></p>
					</li>
										<li>Secret facts about Secret Superstar						<p style="color:#146992;cursor:pointer;font-size: 15px;"><a href="http://www.castindia.in/blogs/details?code=MzM=">Continue Reading..</a></p>
					</li>
										<li>Some unknown facts about amusement roller coaster “Hera Pheri”.						<p style="color:#146992;cursor:pointer;font-size: 15px;"><a href="http://www.castindia.in/blogs/details?code=MzI=">Continue Reading..</a></p>
					</li>
										<li>Kala Kollective – The True Art Collective						<p style="color:#146992;cursor:pointer;font-size: 15px;"><a href="http://www.castindia.in/blogs/details?code=MzE=">Continue Reading..</a></p>
					</li>
									<!--<li>Helping New York fashion photographer Bryan M. Sargent to find the perfect model
					<p style="color:#146992;cursor:pointer;font-size: 15px;">Continue Reading..</p>
				</li>
				<li>Elegance and destruction, a stunning magazine editorial from a model casting in our community
					<p style="color:#146992;cursor:pointer;font-size: 15px;">Continue Reading..</p>
				</li>
				<li>Vogue Arabia Names New Editor-in-Chief
					<p style="color:#146992;cursor:pointer;font-size: 15px;">Continue Reading..</p>
				</li>
				<li>Kick start your modelling career!
					<p style="color:#146992;cursor:pointer;font-size: 15px;">Continue Reading..</p>
				</li>-->
			</ul>
					</div>
                    </div></div>
                    </div>
<?php $this->load->view('/common/footer'); ?>  
