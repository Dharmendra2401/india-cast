

<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
<div class="sb-sidenav-menu">
<div class="nav">
<div class="text-center admin-pic">
<img src="<?php echo base_url(); ?>img/default.png" alt="default.jpg" style="width: 60px;">
<div class="sb-sidenav-menu-heading"><span class="bg-warning bg-admin">Admin</span></div>
</div>

<a class="nav-link" href="<?php echo base_url(); ?>recruiter">
<div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
Dashboard
</a>





<a class="nav-link" href="<?php echo base_url(); ?>recruiter/aboutus">
<div class="sb-nav-link-icon"><i class="fas fa-address-card"></i></div>
About Us
</a>

<a class="nav-link" href="<?php echo base_url(); ?>recruiter/job_list">
<div class="sb-nav-link-icon"><i class="fas fa-briefcase"></i></div>
Jobs List
</a>

<a class="nav-link <?php if(($pagename=='jobs_list')||($pagename=='job_details')){echo "collapsed active";}else{ echo "";} ?>" href="#" data-toggle="collapse" data-target="#collapseLayouts" <?php if($pagename=='recuiter_list'){echo "aria-expanded='true'";}else{ echo "aria-expanded='false'";} ?> aria-controls="collapseLayouts">
<div class="sb-nav-link-icon"><i class="fas fa-briefcase"></i></div>
Jobs
<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
</a>
<div class="collapse <?php if(($pagename=='recuiter_list')||($pagename=='jobs_list') ||($pagename=='job_details')){echo "show";}else{ echo "";} ?>" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
<nav class="sb-sidenav-menu-nested nav">
<a class="nav-link" href="<?php echo base_url(); ?>recruiter/recuiter_list"><div class="sb-nav-link-icon"><i class="fas fa-list-alt"></i></div> Recruiters List</a>
<a class="nav-link" href="<?php echo base_url(); ?>recruiter/jobs_list"><div class="sb-nav-link-icon"><i class="fas fa-briefcase"></i></div> Recruiters Jobs</a>
</nav>
</div>


<a class="nav-link <?php if(($pagename=='events')||($pagename=='view_events')||($pagename=='detail_events')){echo "collapsed active";}else{ echo "";} ?>" href="#" data-toggle="collapse" data-target="#collapseLayoutstwo" <?php if($pagename=='recuiter_list'){echo "aria-expanded='true'";}else{ echo "aria-expanded='false'";} ?> aria-controls="collapseLayouts">
<div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>
Events
<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
</a>
<div class="collapse <?php if(($pagename=='events')||($pagename=='view_events') ||($pagename=='detail_events')){echo "show";}else{ echo "";} ?>" id="collapseLayoutstwo" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
<nav class="sb-sidenav-menu-nested nav">
<a class="nav-link " href="<?php echo base_url(); ?>recruiter/events"><div class="sb-nav-link-icon"><i class="fas fa-calendar-week"></i></div> Events Category</a>
<a class="nav-link <?php if(($pagename=='view_events') ||($pagename=='detail_events')){echo "active";}?>" href="<?php echo base_url(); ?>recruiter/view_events"><div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div> Events List</a>
</nav>
</div>


<a class="nav-link <?php if(($pagename=='blog_catagories')||($pagename=='blog_list')||($pagename=='details_blogs') ){echo "collapsed active";}else{ echo "";} ?>" href="#" data-toggle="collapse" data-target="#collapseLayoutsthree" <?php if($pagename=='recuiter_list'){echo "aria-expanded='true'";}else{ echo "aria-expanded='false'";} ?> aria-controls="collapseLayouts">
<div class="sb-nav-link-icon"><i class="fas fa-blog"></i></div>
Blogs
<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
</a>
<div class="collapse <?php if(($pagename=='blog_catagories')||($pagename=='blog_list')||($pagename=='details_blogs')){echo "show";}else{ echo "";} ?>" id="collapseLayoutsthree" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
<nav class="sb-sidenav-menu-nested nav">
<a class="nav-link " href="<?php echo base_url(); ?>recruiter/blog_catagories"><div class="sb-nav-link-icon"><i class="fas fa-list-alt"></i></div> Blogs Category</a>
<a class="nav-link <?php if(($pagename=='blog_list')||($pagename=='details_blogs') ){echo "active";}?>" href="<?php echo base_url(); ?>recruiter/blog_list"><div class="sb-nav-link-icon"><i class="fas fa-list-ol"></i></div> Blogs Lists</a>
</nav>
</div>



<!-- 
<a class="nav-link" href="<?php echo base_url(); ?>recruiter/slider">
<div class="sb-nav-link-icon"><i class="fas fa-sliders-h"></i></div>
Slider
</a> -->

<a class="nav-link" href="<?php echo base_url();?>recruiter/applicant_list">
<div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
Applicants List
</a>

<a class="nav-link" href="<?php echo base_url();?>recruiter/contact_us">
<div class="sb-nav-link-icon"><i class="fas fa-phone"></i></div>
Contact Us List
</a>

<a class="nav-link" href="<?php echo base_url(); ?>recruiter/logout">
<div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
Logout
</a>
</div>
</div>
<div class="sb-sidenav-footer">

</div>
</nav>