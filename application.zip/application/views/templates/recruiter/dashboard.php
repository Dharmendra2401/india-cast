<!DOCTYPE html>
<html lang="en">
<?php  
include "top_head.php"; 
$title="Dashboard";
?>
    
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
            <?php  include "left_menu.php"; ?>    
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                    <h1 class="mt-4"><?php echo $title;  ?> </h1> 
                    <?php include 'bedcrum.php'; ?>
                    
                <div class="row">
                    <div class="col-md-8">
                        <ol class="bg-info text-white breadcrumb  bg-info">
                        <li class="breadcrumb-item active text-white events-icon"><i class="fas fa-users"></i>   Total Applicants</li>
                    </ol>

                    <div class="row padding-top-manage">
                    <?php  $i=0;foreach($row as $index){?>
                

                    <div class="col-md-3 p-0 border text-center">
                    <h5 class="mb-2 pt-2"><h6><?php echo $index['name'];?></h6><?php //$sql ="SELECT id,profile_ids FROM jobs WHERE profile_ids REGEXP CONCAT('(^|,)(', REPLACE($index[id], ',', '|'), ')(,|$)')";
                    $sql="SELECT * FROM user_profiles where delete_flag='N' and profile_id In ($index[id]) ";
                    $query = $this->db->query($sql);
                    echo $countt=$query->num_rows();
                    ?></p></div>
                    <?php } ?>
               
                </div>
                    </div>
                    <div class="col-md-4">
                    <ol class="bg-info text-white breadcrumb bg-info">
                    <li class="breadcrumb-item active text-white events-icon"><i class="fas fa-user"></i> Account Status </li>
                    </ol>
                    <?php 
                    
                    $status='';
                   if($getrecc['firstname']!=''){
                       $status1=10;
                   }
                   if($getrecc['lastname']!=''){
                    $status2=10;
                } 
                if($getrecc['contact_no']!=''){
                    $status3=10;
                }
                if($getrecc['company_name']!=''){
                    $status4=10;
                } 
                
                if($getrecc['admin_approval']=='Y'){
                    $status6=10;
                }
                
                if($getrecc['email_verified']=='Y'){
                    $status7=5;
                }
                if($getrecc['company_logo']!=''){
                    $status8=10;
                }
                if($getrecc['registration_no']!=''){
                    $status9=10;
                }
                if($getrecc['pan']!=''){
                    $status10=10;
                }
                if($getrecc['gst']!=''){
                    $status11=10;
                }
                if($getrecc['address']!=''){
                    $status12=10;
                }
                if($getrecc['other']!=''){
                    $status13=5;
                } 
                $total=$status1+$status2+$status3+$status4+$status7+$status8+$status9+$status10+$status11+$status12+$status13;
                   
                   ?>
                  
                    <div class="row">
                    <div class="col-md-12 ">
                        <div class="form-top">
                        <h6 class="text-center"><label class="text-white <?php if($total!=100){?>bg-secondary <?php }else {?> bg-success<?php } ?> btn-sm"><?php echo $total;?>% Completed</label></h6>
                    <div class="progress-top rounded"style="background: #f1f1f1;">
                    <div class="progress-bar progress-bar-striped progress-bar-animated rounded" style="height: 9px;width:<?php echo $total;?>%;    background-color: #17a2b8;"></div>
                    </div><br>
                    
                     <div class="row">
                        <div class="col-md-8 col-8 text-left"><h6 class="title"><i class="fas fa-user-check text-warning"></i> Admin Approval:</h6></div>
                        <div class="col-md-4 col-4 text-right"> <?php if($getrecc['admin_approval']=='Y'){?><label class="text-white bg-success btn-sm">Approved</label> <?php }else{?> <label class="text-white bg-danger btn-sm">No Approved</label> <?php } ?></div>

                        <div class="col-md-8 col-8 text-left"><h6 class="title"><i class="fas fa-envelope text-warning"></i> Email Verified:</h6></div>
                        <div class="col-md-4 col-4 text-right"><?php if($getrecc['email_verified']=='Y'){?><label class="text-white bg-success btn-sm">Verify</label> <?php }else{ ?> <label class="text-white bg-danger btn-sm">Unverify</label> <?php } ?></div>

                        <div class="col-md-8 col-8 text-left"> <h6 class="title"><i class="fas fa-briefcase text-warning"></i> Total Jobs:</h6></div>
                        <div class="col-md-4 col-4 text-right"><label class="text-white bg-secondary btn-sm">2</label></div>

                        <div class="col-md-8 col-8 text-left"><h6 class="title"><i class="fas fa-users text-warning"></i> Applied Users:</h6></div>
                        <div class="col-md-4 col-4 text-right"><label class="text-white bg-secondary btn-sm">2</label></div>

                        <div class="col-md-8 col-8 text-left"> <h6 class="title"><i class="fas fa-file-invoice text-warning"></i> Account Status:</h6></div>
                        <div class="col-md-4 col-4 text-right"><?php if( $total==100){?><label class="text-white bg-success btn-sm">Completed<label><?php }else{?> <label class="text-white bg-warning btn-sm">Incomplete<label><?php }?></div>

                        <div class="col-md-6 col-6 text-left"> <h6 class="title"><i class="fas fa-calendar-week text-warning"></i> Registration Date:</h6></div>
                        <div class="col-md-6 col-6 text-right"><label class="text-white bg-secondary btn-sm"><?php echo date("l") .', '.date('d-M-Y',strtotime($getrecc['date_created'])); ?><label></div>

                       

                    </div>

                    </div>
                    </div>
                    </div>
                    </div>



                </div><br>
                 </div>
                </main>
                <?php include "footer.php";  ?>
            </div>
        </div>
       <?php include "scripts.php";  ?>
        
        
    </body>
</html>
