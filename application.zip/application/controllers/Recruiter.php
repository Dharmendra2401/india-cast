<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Recruiter extends CI_Controller {
    public function __construct() {
        parent::__construct(); 
        $this->load->model('Recruiter_model');
        
      }

      public function load_table(){
		$loadpage=$_REQUEST['loadpage'];
		$model=$_REQUEST['model'];
		$row=$this->Recruiter_model->$model();
	
		$row['row']=$row;
		//$mergedata=array_merge_recursive($notify,$row);
		$this->load->view('templates/recruiter/'.$loadpage,$row);
	}

    public function logout(){
        $this->session->unset_userdata('recruiter');
		$this->session->set_flashdata('error','<div class="alert alert-success alert-dismissible fade show" role="alert">
		Logout Successfull!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span></button></div>'); redirect(base_url().'recruiter/login');
		  

      }

    public  function login(){
        $this->Recruiter_model->authfalse();
        if($this->input->post('submit')){
            $password = md5($this->input->post('password'));
            $email=$this->input->post('email');
            $check=$this->Recruiter_model->checkcrediential($email,$password);
            if($check!=''){
                $sessArray['recid']= $check['id'];
                $sessArray['recemail']= $check['email'];
                $this->session->set_userdata('recruiter',$sessArray);
                redirect(base_url().'recruiter/index');
            }else{
                $this->session->set_flashdata('error','<div class="alert alert-danger alert-dismissible fade show" role="alert">Error! Invalid email and password<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); redirect(base_url().'recruiter/login');
            }
        }
        $this->load->view('templates/recruiter/login.php');
    }

    public function index(){
        $this->Recruiter_model->authtrue();
        $rows=$this->Recruiter_model->profile();
        $count=$this->Recruiter_model->jobcount();
        $getrec=$this->Recruiter_model->getrecruiterprofile();
        $row['row']=$rows;
        $countt['countt']=$count;
        $getrecc['getrecc']= $getrec;
        $rowss=array_merge_recursive($row,$countt,$getrecc);
        $this->load->view('templates/recruiter/dashboard.php',$rowss);
    }

    public function job_list(){
        $this->Recruiter_model->authtrue();
        $rows=$this->Recruiter_model->jobs_list();
        $profile=$this->Recruiter_model->profile();
        $city=$this->Recruiter_model->city();
        $profiles['profiles']=$profile;
        $row['row']=$rows;
        $cityy['cityy']=$city;
        $getdata=array_merge_recursive($row,$profiles,$cityy);

        if($this->input->post('add')){
            echo "hello";
            exit();

        }

        $this->load->view('templates/recruiter/job_list.php',$getdata);

    }


}